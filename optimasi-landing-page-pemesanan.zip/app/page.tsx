'use client'

import { useMemo, useState } from 'react'
import { AtSign, ArrowRight, Check, Menu, Minus, Plus, ShoppingBag, Sparkles, X } from 'lucide-react'

const categories = [
  { id: 'best', label: 'Paling dicari' },
  { id: 'baso', label: 'Baso Aci' },
  { id: 'mie', label: 'Mie Ayam' },
  { id: 'batagor', label: 'Batagor' },
  { id: 'minum', label: 'Minuman' },
  { id: 'nasi', label: 'Paket Nasi 10K' },
  { id: 'catering', label: 'Catering' },
  { id: 'snack', label: 'Snackbox' },
  { id: 'cemilan', label: 'Cemilan' },
  { id: 'prasmanan', label: 'Prasmanan' },
]

const menus = [
  { id: 1, category: 'baso', name: 'Baso Aci Paket Hemat', desc: 'Cilok, tahu kuning, pangsit, baso kecil, pilus cikur', price: 8000, visual: 'baso', tag: 'Favorit' },
  { id: 2, category: 'baso', name: 'Baso Aci Paket Pas', desc: 'Lebih lengkap dengan cirawang dan baso besar', price: 10000, visual: 'baso', tag: 'Best seller' },
  { id: 3, category: 'mie', name: 'Mie Ayam Komplit', desc: 'Mie ayam gurih dengan topping pilihan', price: 10000, visual: 'mie', tag: 'Favorit' },
  { id: 4, category: 'batagor', name: 'Batagor Kuah', desc: 'Hangat, gurih, dan pas buat jeda kuliah', price: 8000, visual: 'batagor', tag: 'Hangat' },
  { id: 5, category: 'batagor', name: 'Batagor Kuah + Tulang', desc: 'Porsi mantap dengan topping tulang', price: 10000, visual: 'batagor', tag: 'Porsi mantap' },
  { id: 6, category: 'minum', name: 'Es Teh Manis', desc: 'Teman makan siang paling klasik', price: 3000, visual: 'minum', tag: 'Segar' },
  { id: 7, category: 'nasi', name: 'Paket Nasi 10K', desc: 'Nasi, ayam, tempe, lalap, sambal, kerupuk', price: 10000, visual: 'nasi', tag: 'Hemat' },
  { id: 8, category: 'catering', name: 'Catering Paket 15K', desc: 'Menu rumahan untuk acara kampus dan organisasi', price: 15000, visual: 'catering', tag: 'Pre-order' },
  { id: 9, category: 'snack', name: 'Snackbox Kampus', desc: 'Isi menyesuaikan kebutuhan dan budget acara', price: 10000, visual: 'snack', tag: 'Custom' },
  { id: 10, category: 'cemilan', name: 'Cemilan Mix', desc: 'Kentang, usus, jamur krispi, tulang rangu', price: 7000, visual: 'cemilan', tag: 'Bisa mix' },
  { id: 11, category: 'prasmanan', name: 'Paket Prasmanan', desc: 'Pilih lauk dan sayur sesuai kebutuhan acara', price: 20000, visual: 'prasmanan', tag: 'Custom' },
]

const price = (value: number) => `Rp${value.toLocaleString('id-ID')}`

function FoodVisual({ type, large = false }: { type: string; large?: boolean }) {
  return (
    <div className={`food-visual food-${type} ${large ? 'food-visual-large' : ''}`} aria-hidden="true">
      <span className="food-orb food-orb-one" />
      <span className="food-orb food-orb-two" />
      <span className="food-bowl">{type === 'minum' ? '🥤' : type === 'mie' ? '🍜' : type === 'batagor' ? '🥟' : type === 'cemilan' ? '🍟' : type === 'nasi' ? '🍱' : type === 'snack' ? '🍱' : type === 'catering' ? '🍲' : '🍲'}</span>
      <span className="food-leaf">✦</span>
    </div>
  )
}

export default function Page() {
  const [activeCategory, setActiveCategory] = useState('best')
  const [cart, setCart] = useState<Record<number, number>>({})
  const [cartOpen, setCartOpen] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  const visibleMenus = useMemo(() => activeCategory === 'best' ? menus.slice(0, 6) : menus.filter((item) => item.category === activeCategory), [activeCategory])
  const cartItems = menus.filter((item) => cart[item.id])
  const cartCount = Object.values(cart).reduce((total, count) => total + count, 0)
  const total = cartItems.reduce((sum, item) => sum + item.price * (cart[item.id] || 0), 0)

  function addToCart(id: number) {
    setCart((current) => ({ ...current, [id]: (current[id] || 0) + 1 }))
  }
  function changeCart(id: number, delta: number) {
    setCart((current) => {
      const next = Math.max(0, (current[id] || 0) + delta)
      const updated = { ...current }
      if (next === 0) delete updated[id]
      else updated[id] = next
      return updated
    })
  }

  return (
    <main className="site-shell">
      <nav className="navbar page-width">
        <a className="brand" href="#top" aria-label="Kantin Kopma Unsil beranda">
          <span className="brand-mark">K</span>
          <span><strong>KANTIN KOPMA</strong><small>UNSIL • Tasikmalaya</small></span>
        </a>
        <div className={`nav-links ${menuOpen ? 'nav-links-open' : ''}`}>
          <a href="#menu" onClick={() => setMenuOpen(false)}>Menu</a>
          <a href="#layanan" onClick={() => setMenuOpen(false)}>Layanan</a>
          <a href="#tentang" onClick={() => setMenuOpen(false)}>Tentang kami</a>
        </div>
        <div className="nav-actions">
          <button className="cart-button" onClick={() => setCartOpen(true)} aria-label={`Buka keranjang, ${cartCount} item`}><ShoppingBag size={19} /><span>Keranjang</span>{cartCount > 0 && <b>{cartCount}</b>}</button>
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Buka menu navigasi"><Menu size={22} /></button>
        </div>
      </nav>

      <section className="hero page-width" id="top">
        <div className="hero-copy">
          <div className="eyebrow"><span /> Kantin resmi KOPMA UNSIL</div>
          <h1>Enaknya makan,<br /><em>gak perlu mikir.</em></h1>
          <p>Menu favorit mahasiswa UNSIL, harga bersahabat, dan bisa langsung kamu pesan lewat WhatsApp.</p>
          <div className="hero-actions"><a className="primary-button" href="#menu">Lihat menu <ArrowRight size={18} /></a><a className="text-link" href="#layanan">Mau catering? <span>Pesan di sini</span></a></div>
          <div className="hero-note"><span className="avatar-stack"><i>🍳</i><i>🍜</i><i>🥟</i></span><span><strong>Menu pilihan warga kampus</strong><small>Mulai dari Rp3.000 saja</small></span></div>
        </div>
        <div className="hero-art"><div className="hero-blob" /><FoodVisual type="nasi" large /><span className="art-label label-one">Paket 10K<br /><strong>kenyang!</strong></span><span className="art-label label-two">fresh<br /><strong>every day</strong></span><span className="doodle doodle-one">✳</span><span className="doodle doodle-two">•••</span></div>
      </section>

      <section className="quick-strip"><div className="page-width quick-items"><div><span>01</span><strong>Pesan sesukamu</strong><small>Pilih menu yang kamu mau</small></div><div><span>02</span><strong>Checkout via WhatsApp</strong><small>Praktis, gak pakai ribet</small></div><div><span>03</span><strong>Tinggal ambil</strong><small>Pesanan siap saat kamu datang</small></div></div></section>

      <section className="menu-section page-width" id="menu">
        <div className="section-heading"><div><div className="eyebrow"><span /> Menu hari ini</div><h2>Yang lagi kamu <em>pengen?</em></h2></div><a className="view-all" href="#menu">Lihat semua <ArrowRight size={16} /></a></div>
        <div className="category-scroll">{categories.map((category) => <button key={category.id} className={activeCategory === category.id ? 'category-active' : ''} onClick={() => setActiveCategory(category.id)}>{category.label}</button>)}</div>
        <div className="menu-grid">{visibleMenus.map((item) => <article className="menu-card" key={item.id}><div className="card-image"><FoodVisual type={item.visual} /><span className="menu-tag">{item.tag}</span></div><div className="card-content"><h3>{item.name}</h3><p>{item.desc}</p><div className="card-footer"><strong>{price(item.price)}</strong><button className="add-button" onClick={() => addToCart(item.id)} aria-label={`Tambah ${item.name}`}><Plus size={19} /></button></div></div></article>)}</div>
      </section>

      <section className="service-section page-width" id="layanan"><div className="service-copy"><div className="eyebrow"><span /> Lebih dari sekadar kantin</div><h2>Acara kampusmu,<br /><em>biar kami yang urus.</em></h2><p>Mulai dari snackbox rapat organisasi sampai prasmanan acara besar, kami bantu siapkan makanan yang enak dan sesuai budget.</p><a className="primary-button" href="https://wa.me/6289665234461?text=Halo%20Kantin%20Kopma%20Unsil,%20saya%20ingin%20konsultasi%20catering" target="_blank" rel="noreferrer">Konsultasi gratis <ArrowRight size={18} /></a></div><div className="service-cards"><div className="service-card service-orange"><span className="service-icon">🍱</span><div><h3>Snackbox</h3><p>Praktis untuk rapat dan acara</p></div><ArrowRight size={20} /></div><div className="service-card service-cream"><span className="service-icon">🍲</span><div><h3>Prasmanan</h3><p>Menu lengkap untuk momen besar</p></div><ArrowRight size={20} /></div><div className="service-card service-red"><span className="service-icon">🍛</span><div><h3>Catering harian</h3><p>Makan siang kantor dan organisasi</p></div><ArrowRight size={20} /></div></div></section>

      <section className="about-section page-width" id="tentang"><div className="about-stamp"><Sparkles size={24} /><span>MAKAN ENAK<br />HARGA RAKYAT</span></div><div><div className="eyebrow"><span /> Cerita kami</div><h2>Rasa rumahan,<br /><em>semangat kampus.</em></h2><p>Kantin KOPMA UNSIL hadir untuk jadi tempat makan yang dekat, hangat, dan bisa diandalkan oleh seluruh warga kampus.</p><a className="text-link" href="https://instagram.com/kantinkopma_kopmaunsil" target="_blank" rel="noreferrer"><AtSign size={17} /> @kantinkopma_kopmaunsil</a></div></section>

      <footer><div className="page-width footer-inner"><a className="brand footer-brand" href="#top"><span className="brand-mark">K</span><span><strong>KANTIN KOPMA</strong><small>UNSIL • Tasikmalaya</small></span></a><p>Teman makan warga kampus UNSIL.</p><a href="https://wa.me/6289665234461" target="_blank" rel="noreferrer">0896 6523 4461 <ArrowRight size={16} /></a></div></footer>

      {cartOpen && <div className="cart-overlay" onClick={() => setCartOpen(false)}><aside className="cart-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-header"><div><span className="eyebrow"><span /> Pesananmu</span><h2>Keranjang</h2></div><button onClick={() => setCartOpen(false)} aria-label="Tutup keranjang"><X /></button></div>{cartItems.length === 0 ? <div className="empty-cart"><ShoppingBag size={36} /><p>Keranjangmu masih kosong.</p><button className="primary-button" onClick={() => setCartOpen(false)}>Cari menu</button></div> : <><div className="cart-list">{cartItems.map((item) => <div className="cart-row" key={item.id}><FoodVisual type={item.visual} /><div><strong>{item.name}</strong><small>{price(item.price)}</small><div className="qty"><button onClick={() => changeCart(item.id, -1)}><Minus size={13} /></button><span>{cart[item.id]}</span><button onClick={() => changeCart(item.id, 1)}><Plus size={13} /></button></div></div></div>)}</div><div className="drawer-total"><span>Total sementara</span><strong>{price(total)}</strong></div><a className="primary-button checkout-button" href={`https://wa.me/6289665234461?text=${encodeURIComponent(`Halo Kantin Kopma Unsil, saya mau pesan:\n${cartItems.map((item) => `- ${item.name} x${cart[item.id]}`).join('\n')}\nTotal: ${price(total)}`)}`} target="_blank" rel="noreferrer">Pesan lewat WhatsApp <ArrowRight size={18} /></a><p className="small-note"><Check size={14} /> Admin akan mengonfirmasi ketersediaan pesananmu</p></>}</aside></div>}
    </main>
  )
}
